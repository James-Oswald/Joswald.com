
alert("in");
var list = document.getElementById("extension-settings-list");
list.firstChild.style = "display:none;";